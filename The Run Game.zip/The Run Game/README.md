# The-Run-Game

[NOT OFFICIALLY DONE, THERE ARE STILL MANY ASPECTS I PLAN TO WORK ON. THERE ARE ONLY 2 ENEMIES THAT KEEP SPAWNING AND IT'S VERY BASIC. FEEL FREE TO TRY IT OUT, BUT I WILL GET BACK TO THIS PROJECT LATER. FEEL FREE TO REMIX IT AND MAKE IT BETTER]

You're in the wilderness, it's time for you to run and try to escape while avoiding the obstacles that you face!

It's up to you to time your jumps and get as far as you can and increase your score.

- Simple runner game made with python/pygame - one of my first games.
- There are 3 difficulties: Easy, Medium and Hard.
- Jumping on enemies kills them and you get 2 points each time. There is a very brief surface that shows '+2', feel free to make that better.
- Highscore that doesn't save after you close the window so...

{SCREENSHOTS}

![image](https://github.com/dev-aj0/The-Run-Game/assets/130843616/2ef19412-c06d-45da-97ee-3d4776558d46)
_______________________________________________________________________________________________________________________________
![image](https://github.com/dev-aj0/The-Run-Game/assets/130843616/0ac21d6d-08f6-4ca9-a54f-9246413fde47)
_______________________________________________________________________________________________________________________________
![image](https://github.com/dev-aj0/The-Run-Game/assets/130843616/65fa80e9-c33f-49ce-b6f6-07f51c2595bf)
_______________________________________________________________________________________________________________________________

Thanks for taking a look at this game.
